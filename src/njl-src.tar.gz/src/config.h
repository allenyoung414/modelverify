/*
 * Copyright 2007-2009 ISP RAS (http://www.ispras.ru), UniTESK Lab (http://www.unitesk.com)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef CONFIG_H
#define CONFIG_H

/* Application's configuration.  */
typedef struct {
  /* Java class to execute.  */
  char * mainclass;

  /* Array of classpath entries.  */
  char ** classpath;
  int classpath_sz;

  /* Array of VM parameters.  */
  char ** vmparams;
  int vmparams_sz;

  /* Array of application parameters.  */
  char ** params;
  int params_sz;
} config_t;

void config_init(config_t * config);
void config_set_mainclass(config_t * config, char * name);
void config_add_cp_entry(config_t * config, char * entry);
void config_add_vmparam(config_t * config, char * param);
void config_add_param(config_t * config, char * param);
void config_free(config_t * config);

#endif /* CONFIG_H */
