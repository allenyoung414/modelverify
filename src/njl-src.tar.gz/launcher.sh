#!/bin/sh

`echo "$0" | sed -e 's/\.sh$//'` "$@"
